// Filename: internal/models/routes
package models

import (
	"context"
	"database/sql"
	"time"
)

type Route struct {
	MileageID     int64
	BeginningID   int64
	DestinationID int64
	TotalMiles    int64
}

type RouteModel struct {
	DB *sql.DB
}

// Code to access the database
func (m *RouteModel) Get() (*Route, error) {
	var o Route

	statement := `
				SELECT id, route_name, number_of_miles, total_cost, number_of_tickets_available
				FROM route
				LIMIT 1
				`
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	err := m.DB.QueryRowContext(ctx, statement).Scan(&o.MileageID, &o.BeginningID, &o.DestinationID, &o.TotalMiles)
	if err != nil {
		return nil, err
	}
	return &o, nil
}

// Code to Delete a specific bus
func (m *RouteModel) Delete() error {
	if id < 1 {
		return ErrRecordNotFound
	}

	statement := `
				DELETE FROM route	
				WHERE id = 1
				LIMIT 1
	`
	result, err := m.DB.Exec(statment, id)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return ErrRecordNotFound
	}
	return nil
}
