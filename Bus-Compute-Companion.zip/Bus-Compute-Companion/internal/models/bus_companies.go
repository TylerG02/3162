// Filename: internal/models/bus_schedule.go
package models

import (
	"context"
	"database/sql"
	"time"
)

type BusCompany struct {
	CompanyID   int64
	CompanyName string
}

type BusCompanyModel struct {
	DB *sql.DB
}

// Code to access the database
func (m *BusCompanyModel) Get() (*BusCompany, error) {
	var c BusCompany

	statement := `
				SELECT id, company_name
				FROM bus_companies
				LIMIT 1
				`
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	err := m.DB.QueryRowContext(ctx, statement).Scan(&c.CompanyID, &c.CompanyName)
	if err != nil {
		return nil, err
	}
	return &c, nil
}

// Code to update the database
//func (m *BusCompanyModel) Update() (*BusCompany, error) {

//}

// Code to Delete a specific bus
func (m *BusCompanyModel) Delete() error {
	if id < 1 {
		return ErrRecordNotFound
	}

	statement := `
				DELETE FROM bus_companies	
				WHERE id = 1
				LIMIT 1
	`
	result, err := m.DB.Exec(statment, id)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return ErrRecordNotFound
	}
	return nil
}
