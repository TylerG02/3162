INSERT INTO ticket_orders(id, ticket_id, user_id, seat_id)
VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 5, 3),
(4, 4, 10, 4),
(5, 5, 2, 5),
(6, 6, 3, 6),
(7, 8, 5, 7),
(8, 7, 6, 8);
