INSERT INTO seats(id, seat_name, type_of_seat)
VALUES
(1, '1A', 'single'),
(2, '1B', 'single'),
(3, '2A', 'single'),
(4, '2B', 'single'),
(5, '3A', 'single'),
(6, '3B', 'single'),
(7, '4A', 'single'),
(8, '4B', 'single'),
(9, '5A', 'single'),
(10, '5B', 'single');

