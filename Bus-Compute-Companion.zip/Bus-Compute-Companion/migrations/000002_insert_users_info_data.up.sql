INSERT INTO users_info(id, fname, lname, email, addres, phone_number, passwrd)
VALUES
(1, 'James', 'Camron', 'jcamron@gmail.com', '15 J Street', '6001234', 'monkey123'),
(2, 'Mary', 'Elizabeth', 'mbeth@gmail.com', '25 Mason Avenue', '6123400', 'jesussaves1'),
(3, 'Chris', 'Cuellar', 'ccuellar@hotmail.com', '35 New Town', '6508000', 'new1old1'),
(4, 'Bob', 'Johnson', 'bjohnson@yahoo.com', '45 Central American', '6010203', 'moonman7'),
(5, 'Jerry', 'Mars', 'jmars@gmail.com', '55 Bruno Street', '6008000', 'grenade2007'),
(6, 'Patrick', 'Barrow', 'pbarrow@yahoo.com', '65 UDP Street', '6085050', '2024PUP'),
(7, 'Xander', 'Faber', 'xfaber@hotmail.com', '75 Orange Street', '6098976', '8bones3'),
(8, 'Simon', 'Newman', 'snewman@hotmail.com', '36 New Tone', '6438291', '8one8one'),
(9, 'Marta', 'Kent', 'mkent@gmail.com', '56 Bruno Street', '6373731', 'brunomars7'),
(10, 'Daniella', 'Martin', 'dmartin@gmail.com', '57 UDP Street', '6019876', '1bad2bunny');